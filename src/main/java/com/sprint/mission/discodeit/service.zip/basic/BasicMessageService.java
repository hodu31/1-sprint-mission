package com.sprint.mission.discodeit.service.basic;

import com.sprint.mission.discodeit.dto.request.BinaryContentCreateRequest;
import com.sprint.mission.discodeit.dto.request.MessageCreateRequest;
import com.sprint.mission.discodeit.dto.request.MessageUpdateRequest;
import com.sprint.mission.discodeit.entity.BinaryContent;
import com.sprint.mission.discodeit.entity.Channel;
import com.sprint.mission.discodeit.entity.Message;
import com.sprint.mission.discodeit.entity.MessageAttachment;
import com.sprint.mission.discodeit.entity.User;
import com.sprint.mission.discodeit.repository.BinaryContentRepository;
import com.sprint.mission.discodeit.repository.ChannelRepository;
import com.sprint.mission.discodeit.repository.MessageRepository;
import com.sprint.mission.discodeit.repository.UserRepository;
import com.sprint.mission.discodeit.service.MessageService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.UUID;
import org.springframework.transaction.annotation.Transactional;

@RequiredArgsConstructor
@Service
public class BasicMessageService implements MessageService {

  private final MessageRepository messageRepository;
  private final ChannelRepository channelRepository;
  private final UserRepository userRepository;
  private final BinaryContentRepository binaryContentRepository;

  @Override
  @Transactional
  public Message create(MessageCreateRequest messageCreateRequest,
      List<BinaryContentCreateRequest> binaryContentCreateRequests) {
    UUID channelId = messageCreateRequest.channelId();
    UUID authorId = messageCreateRequest.authorId();

    // 실제 Channel, User 엔티티 조회
    Channel channel = channelRepository.findById(channelId)
        .orElseThrow(
            () -> new NoSuchElementException("Channel with id " + channelId + " does not exist"));
    User author = userRepository.findById(authorId)
        .orElseThrow(
            () -> new NoSuchElementException("Author with id " + authorId + " does not exist"));

    String content = messageCreateRequest.content();
    // 첨부파일은 아직 없으므로 빈 리스트로 생성
    Message message = new Message(content, channel, author, new ArrayList<>());
    // 초기 Message 저장 (필요시 ID 생성)
    message = messageRepository.save(message);

    // 첨부파일 처리: BinaryContent 저장 후 MessageAttachment 생성하여 Message에 추가
    for (BinaryContentCreateRequest attachmentRequest : binaryContentCreateRequests) {
      String fileName = attachmentRequest.fileName();
      String contentType = attachmentRequest.contentType();
      byte[] bytes = attachmentRequest.bytes();

      BinaryContent binaryContent = new BinaryContent(fileName, (long) bytes.length, contentType,
          bytes);
      BinaryContent createdBinaryContent = binaryContentRepository.save(binaryContent);

      MessageAttachment attachment = new MessageAttachment(message, createdBinaryContent);
      message.addAttachment(attachment);
    }

    // 첨부파일이 반영된 Message를 다시 저장하여 최종 상태로 반환
    return messageRepository.save(message);
  }

  @Override
  @Transactional
  public Message find(UUID messageId) {
    return messageRepository.findById(messageId)
        .orElseThrow(
            () -> new NoSuchElementException("Message with id " + messageId + " not found"));
  }

  @Override
  @Transactional
  public List<Message> findAllByChannelId(UUID channelId) {
    // MessageRepository의 메서드 이름을 채널 연관관계에 맞게 사용
    return messageRepository.findAllByChannel_Id(channelId).stream().toList();
  }

  @Override
  @Transactional
  public Message update(UUID messageId, MessageUpdateRequest request) {
    String newContent = request.newContent();
    Message message = messageRepository.findById(messageId)
        .orElseThrow(
            () -> new NoSuchElementException("Message with id " + messageId + " not found"));
    message.update(newContent);
    return messageRepository.save(message);
  }

  @Override
  @Transactional
  public void delete(UUID messageId) {
    Message message = messageRepository.findById(messageId)
        .orElseThrow(
            () -> new NoSuchElementException("Message with id " + messageId + " not found"));

    // 첨부파일(MessageAttachment)에 포함된 BinaryContent 삭제
    message.getAttachments().forEach(attachment -> {
      binaryContentRepository.deleteById(attachment.getAttachment().getId());
    });

    messageRepository.deleteById(messageId);
  }
}
